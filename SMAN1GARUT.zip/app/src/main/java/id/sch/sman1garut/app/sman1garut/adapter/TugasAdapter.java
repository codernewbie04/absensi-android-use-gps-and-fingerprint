package id.sch.sman1garut.app.sman1garut.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Collections;
import java.util.List;

import id.sch.sman1garut.app.sman1garut.R;
import id.sch.sman1garut.app.sman1garut.models.model_tugas.DataTugas;

public class TugasAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context context;
    private LayoutInflater inflater;
    List<DataTugas> data= Collections.emptyList();
    DataTugas current;
    int currentPos=0;

    // create constructor to innitilize context and data sent from MainActivity
    public TugasAdapter(Context context, List<DataTugas> data){
        this.context=context;
        inflater= LayoutInflater.from(context);
        this.data=data;
    }

    // Inflate the layout when viewholder created
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view=inflater.inflate(R.layout.rv_tugas, parent,false);
        MyHolder holder=new MyHolder(view);
        return holder;
    }

    // Bind data
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        // Get current position of item in recyclerview to bind data and assign values from list
        final MyHolder myHolder= (MyHolder) holder;
        final DataTugas current=data.get(position);
        myHolder.textJudul.setText(current.Judul);
        myHolder.textIsi.setText(current.Deskripsi);
        myHolder.textAuthor.setText("- "+ current.Author);
        myHolder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //remove(current);
                Toast.makeText(context, "This is "+  myHolder.textJudul.getText().toString(), Toast.LENGTH_SHORT).show();
            }
        });


    }

    // return total item from List
    @Override
    public int getItemCount() {
        return data.size();
    }


    class MyHolder extends RecyclerView.ViewHolder{
        RelativeLayout cardView;
        TextView textJudul;
        TextView textIsi;
        TextView textAuthor;

        // create constructor to get widget reference
        public MyHolder(View itemView) {
            super(itemView);
            cardView= (RelativeLayout) itemView.findViewById(R.id.cardView);
            textJudul= (TextView) itemView.findViewById(R.id.judul);
            textIsi = (TextView) itemView.findViewById(R.id.desc);
            textAuthor = (TextView) itemView.findViewById(R.id.author);
        }

    }
}

//    public void remove(DataPengumuman item) {
//        int position = data.indexOf(item);
//        data.remove(position);
//        notifyItemRemoved(position);
//    }


