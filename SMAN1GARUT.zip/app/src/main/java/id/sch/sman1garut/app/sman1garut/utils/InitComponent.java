package id.sch.sman1garut.app.sman1garut.utils;

public interface InitComponent {
    public void startInit();
    public void initToolbar();
    public void initUI();
    public void initValue();
    public void initEvent();
}
