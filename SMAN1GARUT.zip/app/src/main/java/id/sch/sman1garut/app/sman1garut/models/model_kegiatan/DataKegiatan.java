package id.sch.sman1garut.app.sman1garut.models.model_kegiatan;

public class DataKegiatan {
    public  int Id;
    public  String Judul, Author, Deskripsi,Mulai, Selesai, Tempat, Waktu, Tanggal;

}
