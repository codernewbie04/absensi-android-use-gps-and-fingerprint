package id.sch.sman1garut.app.sman1garut.models.model_tugas;

public class DataTugas {
    public  int Id;
    public  String Judul, Author, Tanggal, Deskripsi;
}
