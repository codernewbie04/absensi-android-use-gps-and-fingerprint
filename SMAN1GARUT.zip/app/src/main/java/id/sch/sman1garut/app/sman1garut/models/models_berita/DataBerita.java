package id.sch.sman1garut.app.sman1garut.models.models_berita;

public class DataBerita {
    public int Id;
    public String  Judul, Gambar, Isi, Author, Joindate;
}
