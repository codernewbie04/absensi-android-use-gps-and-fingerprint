package id.sch.sman1garut.app.sman1garut.models.model_pengumuman;

public class DataPengumuman {
    public  int Id;
    public  String Judul, Author, IsiPengumuman, Tanggal;

}
